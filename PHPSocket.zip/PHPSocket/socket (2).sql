-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 23, 2019 at 01:45 PM
-- Server version: 8.0.16
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChannelType`
--

CREATE TABLE `ChannelType` (
  `id` int(2) NOT NULL,
  `ChannelType` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ChannelType`
--

INSERT INTO `ChannelType` (`id`, `ChannelType`) VALUES
(0, 'Private'),
(1, 'Group');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chatid` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `userIds` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `channelName` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `channelType` varchar(2) NOT NULL,
  `last_message` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chatid`, `userIds`, `channelName`, `channelType`, `last_message`, `created_at`, `updated_at`) VALUES
('4yYkD1Fk', '2,kH92p', '', '0', ' Bvbvvbvbvbvbvbvbdg no b ', 1563882996045, 1563886347865),
('5BNBA2r6', '2,1', '', '0', 'Hgjhgfhfh', 1563886634296, 1563886749562),
('IlI3TIQs', 'kH92p,1', '', '0', 'Gdfgdfg', 1563805529989, 1563882806701);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` varchar(1000) NOT NULL,
  `chat_id` varchar(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` varchar(11) DEFAULT '0',
  `sender` varchar(11) NOT NULL,
  `receiver` varchar(1000) NOT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `message`, `is_read`, `sender`, `receiver`, `created_at`, `updated_at`) VALUES
('1563805529989IlI3TIQs', 'IlI3TIQs', 'Dfgdfgdfg', '1', 'kH92p', '1', 1563805529989, 1563805529989),
('1563882358112IlI3TIQs', 'IlI3TIQs', 'Nvbnvbnvbnvbnvbnvbnvbnvbnv', '1', 'kH92p', '1', 1563882358112, 1563882358112),
('1563882359607IlI3TIQs', 'IlI3TIQs', 'Nvbnvbnvbnvbnvbnvbnvbnvbnv', '1', 'kH92p', '1', 1563882359607, 1563882359607),
('1563882360110IlI3TIQs', 'IlI3TIQs', 'Nvbnvbnvbnvbnvbnvbnvbnvbnv', '1', 'kH92p', '1', 1563882360110, 1563882360110),
('1563882787469IlI3TIQs', 'IlI3TIQs', 'Gdfgdfg', '1', 'kH92p', '1', 1563882787469, 1563882787469),
('1563882806701IlI3TIQs', 'IlI3TIQs', 'Gdfgdfg', '1', 'kH92p', '1', 1563882806701, 1563882806701),
('15638829960454yYkD1Fk', '4yYkD1Fk', 'Fhfghfgh', '3', '2', 'kH92p', 1563882996045, 1563882996045),
('15638841243924yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfg', '3', '2', 'kH92p', 1563884124392, 1563884124392),
('15638841261124yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfg', '3', '2', 'kH92p', 1563884126112, 1563884126112),
('15638841780884yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884178088, 1563884178088),
('15638841834724yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884183472, 1563884183472),
('15638841858324yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884185832, 1563884185832),
('15638841862244yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884186224, 1563884186224),
('15638841864484yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884186448, 1563884186448),
('15638841866644yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884186664, 1563884186664),
('15638841868484yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884186848, 1563884186848),
('15638841916244yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884191624, 1563884191624),
('15638842162044yYkD1Fk', '4yYkD1Fk', 'Fhfghfghgdgdfgdfgdfgsdfsdfsdf', '3', '2', 'kH92p', 1563884216204, 1563884216204),
('15638842564644yYkD1Fk', '4yYkD1Fk', 'Dfgdgdfgdfg', '3', '2', 'kH92p', 1563884256464, 1563884256464),
('15638842955924yYkD1Fk', '4yYkD1Fk', 'Fggdfgdfg', '3', '2', 'kH92p', 1563884295592, 1563884295592),
('15638843753514yYkD1Fk', '4yYkD1Fk', 'Heee', '3', 'kH92p', '2', 1563884375351, 1563884375351),
('15638843767594yYkD1Fk', '4yYkD1Fk', 'Heee', '3', 'kH92p', '2', 1563884376759, 1563884376759),
('15638843822954yYkD1Fk', '4yYkD1Fk', 'Heee', '3', 'kH92p', '2', 1563884382295, 1563884382295),
('15638843942134yYkD1Fk', '4yYkD1Fk', 'Hiiiiiii', '3', 'kH92p', '2', 1563884394213, 1563884394213),
('15638849066184yYkD1Fk', '4yYkD1Fk', 'Hiiii', '3', 'kH92p', '2', 1563884906618, 1563884906618),
('15638856963074yYkD1Fk', '4yYkD1Fk', 'Dgdfdfg', '3', '2', 'kH92p', 1563885696307, 1563885696307),
('15638857643394yYkD1Fk', '4yYkD1Fk', 'Fgdfgdfg', '3', '2', 'kH92p', 1563885764339, 1563885764339),
('15638857810594yYkD1Fk', '4yYkD1Fk', 'Gfdgdfg', '3', '2', 'kH92p', 1563885781059, 1563885781059),
('15638860209144yYkD1Fk', '4yYkD1Fk', 'Gjhgjg', '3', '2', 'kH92p', 1563886020914, 1563886020914),
('15638860372344yYkD1Fk', '4yYkD1Fk', 'Ghjghjghjghj', '3', '2', 'kH92p', 1563886037234, 1563886037234),
('15638860404984yYkD1Fk', '4yYkD1Fk', 'Ghjghjjh', '3', '2', 'kH92p', 1563886040498, 1563886040498),
('15638860414344yYkD1Fk', '4yYkD1Fk', 'Ghjghj', '3', '2', 'kH92p', 1563886041434, 1563886041434),
('15638860421944yYkD1Fk', '4yYkD1Fk', 'Ghj', '3', '2', 'kH92p', 1563886042194, 1563886042194),
('15638860428344yYkD1Fk', '4yYkD1Fk', 'Ghj', '3', '2', 'kH92p', 1563886042834, 1563886042834),
('15638860434264yYkD1Fk', '4yYkD1Fk', 'Ghj', '3', '2', 'kH92p', 1563886043426, 1563886043426),
('15638860588424yYkD1Fk', '4yYkD1Fk', 'Gdfgfdgdfg', '3', '2', 'kH92p', 1563886058842, 1563886058842),
('15638860615864yYkD1Fk', '4yYkD1Fk', 'Dfgdfg', '3', '2', 'kH92p', 1563886061586, 1563886061586),
('15638860623224yYkD1Fk', '4yYkD1Fk', 'Fgh', '3', '2', 'kH92p', 1563886062322, 1563886062322),
('15638860630824yYkD1Fk', '4yYkD1Fk', 'Ffgh', '3', '2', 'kH92p', 1563886063082, 1563886063082),
('15638860638184yYkD1Fk', '4yYkD1Fk', 'Fdgh', '3', '2', 'kH92p', 1563886063818, 1563886063818),
('15638860642984yYkD1Fk', '4yYkD1Fk', 'Fgh', '3', '2', 'kH92p', 1563886064298, 1563886064298),
('15638860647864yYkD1Fk', '4yYkD1Fk', 'Fgh', '3', '2', 'kH92p', 1563886064786, 1563886064786),
('15638860652424yYkD1Fk', '4yYkD1Fk', 'Fgh', '3', '2', 'kH92p', 1563886065242, 1563886065242),
('15638860656424yYkD1Fk', '4yYkD1Fk', 'Fgh', '3', '2', 'kH92p', 1563886065642, 1563886065642),
('15638860661624yYkD1Fk', '4yYkD1Fk', 'Fgh', '3', '2', 'kH92p', 1563886066162, 1563886066162),
('15638860735064yYkD1Fk', '4yYkD1Fk', 'Fghgfhfghfghfghfghfghfghfghfghfghfghfghfgh', '3', '2', 'kH92p', 1563886073506, 1563886073506),
('15638860760504yYkD1Fk', '4yYkD1Fk', 'Fghfghfghfghfghfgh', '3', '2', 'kH92p', 1563886076050, 1563886076050),
('15638860774984yYkD1Fk', '4yYkD1Fk', 'Fghfghfgh', '3', '2', 'kH92p', 1563886077498, 1563886077498),
('15638860793064yYkD1Fk', '4yYkD1Fk', 'Fghfghfgh', '3', '2', 'kH92p', 1563886079306, 1563886079306),
('15638860811384yYkD1Fk', '4yYkD1Fk', 'Trhyhgfhgf', '3', '2', 'kH92p', 1563886081138, 1563886081138),
('15638860824104yYkD1Fk', '4yYkD1Fk', 'Ghfghfgh', '3', '2', 'kH92p', 1563886082410, 1563886082410),
('15638860832104yYkD1Fk', '4yYkD1Fk', 'Fghfgh', '3', '2', 'kH92p', 1563886083210, 1563886083210),
('15638860841704yYkD1Fk', '4yYkD1Fk', 'Fghgfh', '3', '2', 'kH92p', 1563886084170, 1563886084170),
('15638860883394yYkD1Fk', '4yYkD1Fk', 'Hiii', '3', 'kH92p', '2', 1563886088339, 1563886088339),
('15638862509214yYkD1Fk', '4yYkD1Fk', 'Sdfsdfsdf', '3', '2', 'kH92p', 1563886250921, 1563886250921),
('15638862543054yYkD1Fk', '4yYkD1Fk', 'Dfsdfsdf', '3', '2', 'kH92p', 1563886254305, 1563886254305),
('15638862629144yYkD1Fk', '4yYkD1Fk', 'Dfgdfgdfgg', '3', '2', 'kH92p', 1563886262914, 1563886262914),
('15638863439154yYkD1Fk', '4yYkD1Fk', 'Hiiiiiiiiiiiiiiiiii', '3', 'kH92p', '2', 1563886343915, 1563886343915),
('15638863478654yYkD1Fk', '4yYkD1Fk', ' Bvbvvbvbvbvbvbvbdg no b ', '3', 'kH92p', '2', 1563886347865, 1563886347865),
('15638866342965BNBA2r6', '5BNBA2r6', 'Fghfghfgh', '1', '2', '1', 1563886634296, 1563886634296),
('15638866647605BNBA2r6', '5BNBA2r6', 'Gfhgfhfghfgh', '3', '2', '1', 1563886664760, 1563886664760),
('15638867495625BNBA2r6', '5BNBA2r6', 'Hgjhgfhfh', '3', '1', '2', 1563886749562, 1563886749562);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `onlinestatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `photo`, `password`, `onlinestatus`) VALUES
('1', 'Jitendra', 'jitendra@gmail.com', 'sample.jpg', '123', 0),
('2', 'Vishal', 'vishal@gmail.com', '', '123', 0),
('3', 'Dhrupal', 'dhrupal@gmail.com', '', '123', 0),
('kH92p', 'Ravi', 'ravi@gmail.com', '', '123', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
