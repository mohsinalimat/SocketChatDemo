-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 19, 2019 at 02:32 PM
-- Server version: 8.0.16
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChannelType`
--

CREATE TABLE `ChannelType` (
  `id` int(2) NOT NULL,
  `ChannelType` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ChannelType`
--

INSERT INTO `ChannelType` (`id`, `ChannelType`) VALUES
(0, 'Private'),
(1, 'Group');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chatid` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `userIds` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `channelName` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `channelType` varchar(2) NOT NULL,
  `last_message` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chatid`, `userIds`, `channelName`, `channelType`, `last_message`) VALUES
('mVWTBilu', 'kH92p,2', '', '0', 'Fdsfsdfsd');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` varchar(1000) NOT NULL,
  `chat_id` varchar(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` varchar(11) DEFAULT '0',
  `sender` varchar(11) NOT NULL,
  `receiver` varchar(1000) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `message`, `is_read`, `sender`, `receiver`) VALUES
('1563534827289mVWTBilu', 'mVWTBilu', 'Hi', '0', 'kH92p', '2'),
('1563534991788mVWTBilu', 'mVWTBilu', 'Fsdfsdf', '1', 'kH92p', '2'),
('1563537198343mVWTBilu', 'mVWTBilu', 'Hi', '1', 'kH92p', '2'),
('1563537647725mVWTBilu', 'mVWTBilu', 'Hi', '1', 'kH92p', '2'),
('1563538546411mVWTBilu', 'mVWTBilu', 'Gdfgdfgdfg', '1', '2', 'kH92p'),
('1563538900468mVWTBilu', 'mVWTBilu', 'Sdfsdfsdf', '1', '2', 'kH92p'),
('1563539355084mVWTBilu', 'mVWTBilu', 'Dfgdfgdf', '1', '2', 'kH92p'),
('1563539524013mVWTBilu', 'mVWTBilu', 'Dsfsdf', '1', '2', 'kH92p'),
('1563540833703mVWTBilu', 'mVWTBilu', 'Sdfsdf', '1', '2', 'kH92p'),
('1563540882391mVWTBilu', 'mVWTBilu', 'Sfsdfsdfsdf', '1', '2', 'kH92p'),
('1563541396773mVWTBilu', 'mVWTBilu', 'Cvbcvbcbv', '1', '2', 'kH92p'),
('1563541439093mVWTBilu', 'mVWTBilu', 'Hgfjhgjhgjh', '1', '2', 'kH92p'),
('1563541460750mVWTBilu', 'mVWTBilu', 'Hgjghjgjh', '1', '2', 'kH92p'),
('1563541518118mVWTBilu', 'mVWTBilu', 'Gdgfdfgf', '1', '2', 'kH92p'),
('1563544076912mVWTBilu', 'mVWTBilu', 'Dgdfgdgdfgdfg', '1', '2', 'kH92p'),
('1563544129038mVWTBilu', 'mVWTBilu', 'Dgfdgddgdfg', '3', '2', 'kH92p'),
('1563544176230mVWTBilu', 'mVWTBilu', 'Dfsdfsdf', '3', '2', 'kH92p'),
('1563544251899mVWTBilu', 'mVWTBilu', 'Hiii', '3', 'kH92p', '2'),
('1563544351776mVWTBilu', 'mVWTBilu', 'Hiii', '3', 'kH92p', '2'),
('1563544436286mVWTBilu', 'mVWTBilu', 'Dfgdfgdfgdfg', '3', '2', 'kH92p'),
('1563544727125mVWTBilu', 'mVWTBilu', 'Fsdfsdfs', '3', '2', 'kH92p'),
('1563544750589mVWTBilu', 'mVWTBilu', 'Sdfsdfsdf', '3', '2', 'kH92p'),
('1563544784127mVWTBilu', 'mVWTBilu', 'Hiii', '3', 'kH92p', '2'),
('1563544882957mVWTBilu', 'mVWTBilu', 'Fdfgdfg', '3', '2', 'kH92p'),
('1563544899164mVWTBilu', 'mVWTBilu', 'Dfgdfgf', '3', '2', 'kH92p'),
('1563544954485mVWTBilu', 'mVWTBilu', 'Dsfsdfsdfsfd', '3', '2', 'kH92p'),
('1563544970628mVWTBilu', 'mVWTBilu', 'Sdfsfddsf', '3', '2', 'kH92p'),
('1563544979372mVWTBilu', 'mVWTBilu', 'Dfgdfgd', '3', '2', 'kH92p'),
('1563545057735mVWTBilu', 'mVWTBilu', 'Fsfsdfsdfsd', '1', 'kH92p', '2'),
('1563545086782mVWTBilu', 'mVWTBilu', 'Dfgfdgdfgdgf', '2', '2', 'kH92p'),
('1563545164816mVWTBilu', 'mVWTBilu', 'Ffsfsdfsfs', '2', 'kH92p', '2'),
('1563545308256mVWTBilu', 'mVWTBilu', 'Njhmhjhj', '2', 'kH92p', '2'),
('1563545622422mVWTBilu', 'mVWTBilu', 'Gdfgdfgdfg', '2', '2', 'kH92p'),
('1563545685485mVWTBilu', 'mVWTBilu', 'Fdsfsdfsdf', '2', '2', 'kH92p'),
('1563545694973mVWTBilu', 'mVWTBilu', 'Sdfsdfsdf', '2', '2', 'kH92p'),
('1563545805765mVWTBilu', 'mVWTBilu', 'Fsdffdgdfg', '2', '2', 'kH92p'),
('1563545950117mVWTBilu', 'mVWTBilu', 'Dfsgdfgdfg', '2', '2', 'kH92p'),
('1563545985861mVWTBilu', 'mVWTBilu', 'Dfgdfgdfg', '2', '2', 'kH92p'),
('1563546016853mVWTBilu', 'mVWTBilu', 'Dsgdfdfg', '2', '2', 'kH92p'),
('1563546063356mVWTBilu', 'mVWTBilu', 'Dfgdfgdfg', '2', '2', 'kH92p'),
('1563546120492mVWTBilu', 'mVWTBilu', 'Tututyutyu', '1', '2', 'kH92p'),
('1563546359488mVWTBilu', 'mVWTBilu', 'Dfgdfgdfgdgfdfg', '2', '2', 'kH92p'),
('1563546466076mVWTBilu', 'mVWTBilu', 'Hello', '2', 'kH92p', '2'),
('1563546486220mVWTBilu', 'mVWTBilu', 'Dfgdfdfg', '2', '2', 'kH92p'),
('1563546574547mVWTBilu', 'mVWTBilu', 'Dfgdfgdfg', '2', '2', 'kH92p'),
('1563546639361mVWTBilu', 'mVWTBilu', 'Fgdgdfgfg', '3', '2', 'kH92p'),
('1563546649595mVWTBilu', 'mVWTBilu', 'Sadas', '2', 'kH92p', '2'),
('1563546649723mVWTBilu', 'mVWTBilu', 'Dfgfgh', '3', '2', 'kH92p'),
('1563546666051mVWTBilu', 'mVWTBilu', 'Dfggdfgdfggfhfghgfhfghfghfgh', '3', '2', 'kH92p'),
('1563546711967mVWTBilu', 'mVWTBilu', 'Hello', '3', 'kH92p', '2'),
('1563546741097mVWTBilu', 'mVWTBilu', 'Fdsfsdfsd', '2', 'kH92p', '2');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `photo`, `password`) VALUES
('1', 'Jitendra', 'jitendra@gmail.com', 'sample.jpg', '123'),
('2', 'Vishal', 'vishal@gmail.com', '', '123'),
('3', 'Dhrupal', 'dhrupal@gmail.com', '', '123'),
('kH92p', 'Ravi', 'ravi@gmail.com', '', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
