-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 18, 2019 at 01:58 PM
-- Server version: 8.0.16
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChannelType`
--

CREATE TABLE `ChannelType` (
  `id` int(2) NOT NULL,
  `ChannelType` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ChannelType`
--

INSERT INTO `ChannelType` (`id`, `ChannelType`) VALUES
(0, 'Private'),
(1, 'Group');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chatid` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `userIds` varchar(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `channelName` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `channelType` varchar(2) NOT NULL,
  `last_message` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chatid`, `userIds`, `channelName`, `channelType`, `last_message`) VALUES
('mVWTBilu', 'kH92p,2', '', '0', 'Hello');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `chat_id` varchar(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` varchar(11) DEFAULT '0',
  `sender` varchar(11) NOT NULL,
  `receiver` varchar(1000) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `message`, `is_read`, `sender`, `receiver`) VALUES
(79, 'mVWTBilu', 'Hi', '0', 'kH92p', '2'),
(80, 'mVWTBilu', 'Jhhj', '0', 'kH92p', '2'),
(81, 'mVWTBilu', 'Kfdjfh', '0', 'kH92p', '2'),
(82, 'mVWTBilu', 'Asasas', '0', 'kH92p', '2'),
(83, 'mVWTBilu', 'Fsdfsdfsdf', '0', 'kH92p', '2'),
(84, 'mVWTBilu', 'DshjvfcdgsafhDAFDSAGHERWHDJGSG', '0', 'kH92p', '2'),
(85, 'mVWTBilu', 'Sdfdsfsdfsdf', '0', 'kH92p', '2'),
(86, 'mVWTBilu', 'Fhgfhfghf', '0', 'kH92p', '2'),
(87, 'mVWTBilu', 'Hiiiiiii', '0', 'kH92p', '2'),
(88, 'mVWTBilu', 'Fdfsfsdfsdfsdfsdfdsfdsfssdfdsfdsfdsfsd', '0', 'kH92p', '2'),
(89, 'mVWTBilu', 'Bvnncbvn', '0', 'kH92p', '2'),
(90, 'mVWTBilu', 'Gggggggggggggggggg', '0', 'kH92p', '2'),
(91, 'mVWTBilu', 'Qwwww', '0', 'kH92p', '2'),
(92, 'mVWTBilu', 'Kokokkok', '0', 'kH92p', '2'),
(93, 'mVWTBilu', 'Nbmvnbgnjsvghsdfsgdfshfshjnj', '0', 'kH92p', '2'),
(94, 'mVWTBilu', 'Fghfghfgh', '0', '2', 'kH92p'),
(95, 'mVWTBilu', 'Dgdgdgdfg', '0', '2', 'kH92p'),
(96, 'mVWTBilu', 'Gdfgdgdfg', '0', '2', 'kH92p'),
(97, 'mVWTBilu', 'Hgfhfgh', '0', '2', 'kH92p'),
(98, 'mVWTBilu', 'Gdfgdfg', '0', '2', 'kH92p'),
(99, 'mVWTBilu', 'Fdgdfg', '0', '2', 'kH92p'),
(100, 'mVWTBilu', 'Fdjdlksfjsdlkfjlskdjflksdflkdskfjsdlfjlksdfskldfjslkdfjklsdjflksdjfklsdjflksjfdsjdflkjsdlfkjskldfjlksdflksjdlkfjsdlkfjlksdfjlsdjflkskjfsdlfsdf', '0', '2', 'kH92p'),
(101, 'mVWTBilu', 'Hiii', '0', 'kH92p', '2'),
(102, 'mVWTBilu', 'Hello how are You?', '0', 'kH92p', '2'),
(103, 'mVWTBilu', 'Dffdgfdgdfg', '0', '2', 'kH92p'),
(104, 'mVWTBilu', 'Fine', '0', '2', 'kH92p'),
(105, 'mVWTBilu', 'Okkay', '0', 'kH92p', '2'),
(106, 'mVWTBilu', 'Done', '0', '2', 'kH92p'),
(107, 'mVWTBilu', 'Done', '0', 'kH92p', '2'),
(108, 'mVWTBilu', 'Ghughra jevu', '0', '2', 'kH92p'),
(109, 'mVWTBilu', 'Are ready', '0', 'kH92p', '2'),
(110, 'mVWTBilu', 'Vcvcvbcvbcvb', '0', '2', 'kH92p'),
(111, 'mVWTBilu', 'Hello', '0', 'kH92p', '2');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `photo`, `password`) VALUES
('1', 'Jitendra', 'jitendra@gmail.com', 'sample.jpg', '123'),
('2', 'Vishal', 'vishal@gmail.com', '', '123'),
('3', 'Dhrupal', 'dhrupal@gmail.com', '', '123'),
('kH92p', 'Ravi', 'ravi@gmail.com', '', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
