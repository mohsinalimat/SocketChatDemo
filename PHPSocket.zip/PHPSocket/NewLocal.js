var express = require('express');
const app = express();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var mysql = require('mysql');
const multer = require('multer');
var upload = multer({ dest: '/tmp/'});
var fs = require("fs");
var path = require('path')

var con = mysql.createConnection({
	host: "localhost",
    port : "3306",
	user: "root",
	password: "",
	database: "socket",
    charset : 'utf8mb4_bin',
    multipleStatements: true
});

//app.use(express.static('public'));
app.use('/static',express.static('static'));

app.get('/', function(req, res){
	res.sendFile(__dirname + '/static/Login.html')
});

// File input field name is simply 'file'
app.post('/file_upload', upload.single('file'), function(req, res) {
    var file = "/Applications/XAMPP/xamppfiles/htdocs/Images" + '/' + req.file.originalname;
    fs.rename(req.file.path, file, function(err) {
        if (err) {
            res.sendStatus(500);
        } else {
            res.json({ message: 'File uploaded successfully',filename: "http://172.20.10.5/Images/" + req.file.originalname});
        }
    })
})

io.on('connection', function(socket){
    let sender = socket.handshake.query.user_id
    console.log('User Connected ---> ' + sender)
      
    socket.on('Login', function(data,callback){
              
        let email = data.email.toString()
        let password = data.password.toString()
              
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
              
            con.query(newChatSql, function (err, newChatSqlResult) {
                console.log(newChatSqlResult)
                if(newChatSqlResult){
                    callback(newChatSqlResult[0])
                }else{
                    callback(newChatSqlResult)
                }
            })
        })
    })
      
    socket.on('SignUp', function(data,callback){
        
        let email = data.email.toString();
        let password = data.password.toString();
        let name = data.name.toString();
        let photo = data.photo.toString();

        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            con.query(newChatSql, function (err, newChatSqlResult) {
                
                if(newChatSqlResult.length > 0){
                    let obj = newChatSqlResult[0]
                    callback(obj)
                }else{
                    var newChatSql = "Insert into users (name,email,photo,password,onlinestatus) values('"+name+"','"+ email +"','" +photo +"','"+password+"', 1); SELECT * from users where id = LAST_INSERT_ID()"
                    con.query(newChatSql, function (err, newSqlResult) {
                        
                        if(newSqlResult){
                              let obj = newSqlResult[1][0]
                              callback(obj)
                        }else{
                            callback("error while insert record")
                        }
                    })
                }
            })
        })
    })
      
      
    socket.on('disconnect', function(){
		console.log('user disconnected ---> ' + sender)
	})
})

http.listen(3000, function(){
    console.log(__dirname)
	console.log('listening on *:3000');
})
