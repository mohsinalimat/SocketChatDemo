-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 07, 2019 at 03:39 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChannelType`
--

CREATE TABLE `ChannelType` (
  `id` int(2) NOT NULL,
  `ChannelType` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `ChannelType`
--

INSERT INTO `ChannelType` (`id`, `ChannelType`) VALUES
(1, 'Private'),
(2, 'Group'),
(3, 'Broadcast');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chatid` bigint(20) NOT NULL,
  `userIds` varchar(50000) NOT NULL,
  `createdBy` bigint(20) NOT NULL,
  `channelName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `channelType` varchar(2) NOT NULL,
  `channelPic` varchar(1000) NOT NULL,
  `last_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chatid`, `userIds`, `createdBy`, `channelName`, `channelType`, `channelPic`, `last_message`, `created_at`, `updated_at`) VALUES
(1565184068, '12,14,13', 13, 'bsbbsbs', '3', 'http://192.168.1.85/Images/B10011BC-9E3C-4F16-9418-078D6C55C353.jpeg', 'Csvacacacacacaca', 1565184068096, 1565185028917);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) NOT NULL,
  `chat_id` bigint(20) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_read` varchar(11) DEFAULT '0',
  `senderName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `sender` bigint(20) NOT NULL,
  `receiver` varchar(1000) NOT NULL,
  `msgtype` int(11) NOT NULL,
  `mediaurl` varchar(10000) NOT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL,
  `date` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `message`, `is_read`, `senderName`, `sender`, `receiver`, `msgtype`, `mediaurl`, `created_at`, `updated_at`, `date`) VALUES
(1565185028917, 1565184068, 'Csvacacacacacaca', '1', 'Ravi', 13, '12', 0, '', 1565185028917, 1565185028917, '2019-08-07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `onlinestatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `photo`, `password`, `onlinestatus`) VALUES
(12, 'vishal', 'vishal@gmail.com', 'http://192.168.1.85/Images/EE1C5EC2-99E2-4529-95AB-1E35ADAEC0A7.jpeg', '123', 1),
(13, 'Ravi', 'ravi@gmail.com', 'http://192.168.1.85/Images/D952E2D0-796C-4FDE-A357-B9EF9C7A305C.jpeg', '123', 1),
(14, 'prashant', 'prashant@gmail.com', 'http://192.168.1.85/Images/E24CC30E-9588-4290-A16D-5D87F06FF53A.jpeg', '123', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ChannelType`
--
ALTER TABLE `ChannelType`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ChannelType`
--
ALTER TABLE `ChannelType`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
