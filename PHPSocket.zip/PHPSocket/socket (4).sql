-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 02, 2019 at 03:40 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChannelType`
--

CREATE TABLE `ChannelType` (
  `id` int(2) NOT NULL,
  `ChannelType` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `ChannelType`
--

INSERT INTO `ChannelType` (`id`, `ChannelType`) VALUES
(0, 'Private'),
(1, 'Group');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chatid` varchar(11) NOT NULL,
  `userIds` varchar(11) NOT NULL,
  `channelName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `channelType` varchar(2) NOT NULL,
  `last_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chatid`, `userIds`, `channelName`, `channelType`, `last_message`, `created_at`, `updated_at`) VALUES
('MWmI4h4X', 'yerwe,LVg04', '', '0', 'Hiii', 1564752809402, 1564752809402),
('Pe81NqX3', 'yerwe,w2nJe', '', '0', '', 1564751736528, 1564752727783);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` varchar(1000) NOT NULL,
  `chat_id` varchar(11) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_read` varchar(11) DEFAULT '0',
  `sender` varchar(11) NOT NULL,
  `receiver` varchar(1000) NOT NULL,
  `msgtype` int(11) NOT NULL,
  `mediaurl` varchar(10000) NOT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `message`, `is_read`, `sender`, `receiver`, `msgtype`, `mediaurl`, `created_at`, `updated_at`) VALUES
('1564751736528Pe81NqX3', 'Pe81NqX3', 'Hi', '3', 'yerwe', 'w2nJe', 0, '', 1564751736528, 1564752657264),
('1564751768606Pe81NqX3', 'Pe81NqX3', 'Hello', '3', 'w2nJe', 'yerwe', 0, '', 1564751768606, 1564752672743),
('1564751830875Pe81NqX3', 'Pe81NqX3', 'Bxbxbx', '3', 'yerwe', 'w2nJe', 0, '', 1564751830875, 1564752657265),
('1564751843326Pe81NqX3', 'Pe81NqX3', 'Kem 6o', '3', 'w2nJe', 'yerwe', 0, '', 1564751843326, 1564752672744),
('1564751847159Pe81NqX3', 'Pe81NqX3', '👺', '3', 'w2nJe', 'yerwe', 0, '', 1564751847158, 1564752672744),
('1564751862960Pe81NqX3', 'Pe81NqX3', '🤥', '3', 'w2nJe', 'yerwe', 0, '', 1564751862960, 1564752672744),
('1564751999195Pe81NqX3', 'Pe81NqX3', '', '3', 'w2nJe', 'yerwe', 2, 'http://192.168.1.85/Images/trim.66856CE6-E026-4742-B9B8-A51CA7CE16BD.MOV', 1564751999195, 1564752672744),
('1564752027426Pe81NqX3', 'Pe81NqX3', '', '3', 'w2nJe', 'yerwe', 2, 'http://192.168.1.85/Images/trim.B9A48344-5F70-4946-B545-AF67588DB042.MOV', 1564752027426, 1564752672745),
('1564752493492Pe81NqX3', 'Pe81NqX3', '', '1', 'yerwe', 'w2nJe', 2, 'http://192.168.1.85/Images/trim.152D66D8-55F0-4C4C-8C0D-5FC60D3FD749.MOV', 1564752493492, 1564752493492),
('1564752727783Pe81NqX3', 'Pe81NqX3', '', '1', 'yerwe', 'w2nJe', 2, 'http://192.168.1.85/Images/trim.C3CA0891-F8A4-41D8-85EA-F9AF19CBCF56.MOV', 1564752727783, 1564752727783),
('1564752809402MWmI4h4X', 'MWmI4h4X', 'Hiii', '3', 'yerwe', 'LVg04', 0, '', 1564752809402, 1564752815271);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `onlinestatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `photo`, `password`, `onlinestatus`) VALUES
('LVg04', 'Jitendra', 'jit@gmail.com', 'http://192.168.1.85/Images/656ECFAC-671C-47F8-AC14-EE51EFD097ED.jpeg', '123', 0),
('w2nJe', 'vishal', 'vishal@gmail.com', 'http://192.168.1.85/Images/672BF9D9-E259-4E71-B366-C164221FCD4B.jpeg', '123', 0),
('yerwe', 'Ravi', 'ravi@moweb.com', 'http://192.168.1.85/Images/5EEC9E76-2823-4F0E-BD0A-37425C575D50.jpeg', '123456', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
