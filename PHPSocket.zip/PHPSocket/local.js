var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var mysql = require('mysql');

var con = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "Vishal@125",
	database: "socket"
});

app.get('/', function(req, res){
	res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(socket){
	let sender = socket.handshake.query.user_id;
	console.log('a user connected with id - '+ sender);

	socket.on('sendMessage', function(msg,callback){
		let chat_id = msg.chat_id.toString();
		let sender = msg.sender.toString();
		let receiver = msg.receiver.toString();
		let message = msg.message.toString();
        let status = msg.status.toString();
        let channelType = msg.channelType.toString();
        con.connect(function(err) {
                    
            var newChatSql = "SELECT * FROM chats WHERE chatid = '" + chat_id + "'"
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult.length > 0){
                    var lastMsgSql = "UPDATE chats SET last_message='"+ message +"' WHERE id="+chat_id;
                    con.query(lastMsgSql, function (err, lastMsgSqlResult) {
                    });
                }else{
                    let userids = sender + "," + receiver
                    let insertSqlChatList = "INSERT INTO chats(chatid,userIds,channelName,channelType,last_message) values('"+chat_id+ "','"+userids+"','','"+channelType+"','"+message+"')"
                    console.log(insertSqlChatList)
                    con.query(insertSqlChatList, function (err, newChatListSqlResult) {
                        console.log(newChatListSqlResult)
                        if(newChatListSqlResult){
                            let channelName = "channelList/" + receiver
                            io.emit(channelName, msg);
                        }
                    });
                }
            });
            var newMsgSql = "INSERT INTO chat_messages(chat_id, message, is_read, sender,receiver) VALUES ('"+chat_id+"','"+ message+"','"+status+"','"+sender+"','"+receiver+"')";
            console.log(newMsgSql);
            con.query(newMsgSql, function (err, newMsgSqlResult) {
                if(newMsgSqlResult){
                    msg.status = "1"
                    callback(msg)
                    let channelName = "receiveMessage/" + receiver
                    io.emit(channelName, msg);
                }
            });
        });
	});
      
    socket.on('UserList', function(callback){
              
        con.connect(function(err) {
            var newChatSql = "Select * from users"
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult){
                    callback(newChatSqlResult)
                }
            });
        });
    });
      
      
    socket.on('channelList', function(data,callback){
        console.log(data.senderId)
        let sender_Id = data.senderId.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from chats WHERE FIND_IN_SET('"+sender_Id+"',UserIDs)"
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult){
                    callback(newChatSqlResult)
                }else{
                    callback(newChatSqlResult)
                }
            });
        });
    });
      
    socket.on('Authenticate', function(data,callback){
        console.log(data)
        let email = data.email.toString();
        let password = data.password.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                console.log(newChatSqlResult)
                if(newChatSqlResult){
                    callback(newChatSqlResult[0])
                }else{
                    callback(newChatSqlResult[0])
                }
            });
        });
    });
      
    socket.on('GetChatId', function(data,callback){
        let UserIDs = data.UserIDs.toString();
        con.connect(function(err) {
            let idsArray = UserIDs.split(',');
            var newData = "";
            for(var i = 0; i < idsArray.length; i++){
                if (idsArray.length - 1 == i) {
                    newData += "FIND_IN_SET('"+idsArray[i].trim()+"', UserIDs)"
                }else{
                    newData += "FIND_IN_SET('"+idsArray[i].trim()+"', UserIDs) AND "
                }
            }
                    
            var newChatSql = "SELECT * FROM chats WHERE " + newData
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                
                if(newChatSqlResult.length > 0) {
                      console.log(newChatSqlResult)
                      callback({"ChatId":newChatSqlResult[0].chatid})
                }else{
                    callback({"ChatId":makeid(8)})
                }
            });
        });
    });
      
    socket.on('SignUp', function(data,callback){
        let email = data.email.toString();
        let password = data.password.toString();
        let name = data.name.toString();
        let photo = data.photo.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            con.query(newChatSql, function (err, newChatSqlResult) {
                console.log(newChatSqlResult)
                if(newChatSqlResult.length > 0){
                    let obj = newChatSqlResult[0]
                    callback(obj)
                }else{
                    console.log(data)
                    let id = makeid(5)
                    console.log(id)
                    var newChatSql = "Insert into users values('" +id+ "','" + name + "','" + email + "','" + photo + "','" + password + "')"
                    console.log(newChatSql)
                    con.query(newChatSql, function (err, newSqlResult) {
                        console.log(newSqlResult)
                        if(newSqlResult){
                              callback({"name" : name,"email":email,"id":id})
                        }else{
                            callback("error while insert record")
                        }
                    });
                }
            });
        });
    });

    function makeid(length) {
      var result           = '';
      var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var charactersLength = characters.length;
      for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }
      return result;
    }
      
	socket.on('disconnect', function(){
		console.log('user disconnected');
	});
});

http.listen(3000, function(){
	console.log('listening on *:3000');
});
