var express = require('express');
const app = express();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var mysql = require('mysql');
const multer = require('multer');
var upload = multer({ dest: '/tmp/'});
var fs = require("fs");

var con = mysql.createConnection({
	host: "localhost",
    port : "3306",
	user: "root",
	password: "",
	database: "socket",
    charset : 'utf8mb4_bin',
    multipleStatements: true
});

app.use(express.static('public'));

app.get('/', function(req, res){
	res.sendFile(__dirname + '/index.html');
});

// File input field name is simply 'file'
app.post('/file_upload', upload.single('file'), function(req, res) {
    var file = "/Applications/XAMPP/xamppfiles/htdocs/Images" + '/' + req.file.originalname;
    fs.rename(req.file.path, file, function(err) {
        if (err) {
            res.sendStatus(500);
        } else {
            res.json({ message: 'File uploaded successfully',filename: "http://192.168.1.85/Images/" + req.file.originalname});
        }
    });
});

io.on('connection', function(socket){
	let sender = socket.handshake.query.user_id;
	console.log('a user connected with id - '+ sender);
    
    if(sender != "") {
      updateUsersOnlineStatus(1,sender)
    }
      
	socket.on('sendMessage', function(msg,callback){
        let channelType = msg.channelType.toString()
        if (channelType == "1" || channelType == "2") {
            if (channelType == "1"){
                checkChannelAvailabelORNot(msg)
            }else{
                updateChannelData(msg)
            }
            insertmsg(msg,callback)
        }
	})
    
    function insertmsg(msg,callback){
        let channelType = msg.channelType.toString()
        let chat_id = msg.chat_id
        let sender = msg.sender
        let receiver = msg.receiver
        let message = msg.message.toString()
        let is_read = msg.is_read.toString()
        let created_at = getTimeStamp()
        let id = msg.id
        let msgtype = msg.msgtype.toString()
        let mediaurl = msg.mediaurl.toString()
        let name = msg.name.toString()
        let photo = msg.photo.toString()
        let senderName = msg.senderName.toString()
        let idsArray = msg.receiver.split(',')
      
        con.connect(function(err) {
            var newMsgSql = "INSERT INTO chat_messages(id, chat_id, message, is_read, senderName, sender, receiver, msgtype, mediaurl, created_at, updated_at) VALUES ("+id+","+chat_id+",'"+ message +"','1','"+senderName +"',"+sender +",'"+receiver +"',"+msgtype +",'"+mediaurl +"',"+created_at +","+created_at +")"
            con.query(newMsgSql, function (err, newMsgSqlResult) {
                console.log(err+newMsgSqlResult)
                if(newMsgSqlResult){
                    msg.is_read = "1"
                    callback(msg)
                    for(var i = 0; i < idsArray.length; i++){
                        let channelName = "receiveMessage/" + idsArray[i]
                        io.emit(channelName, msg)
                    }
                }else{
                    callback(newMsgSqlResult)
                }
            })
        })
    }
      
    function updateChannelData(msg){
      let chat_id = msg.chat_id
      let sender = msg.sender
      let receiver = msg.receiver
      let message = msg.message.toString()
      let channelType = msg.channelType.toString()
      let created_at = getTimeStamp()
      let name = msg.name.toString()
      let photo = msg.photo.toString()
      let senderName = msg.senderName.toString()
      let userids = sender + "," + receiver
      
      con.connect(function(err) {
        let userids = sender + "," + receiver
        var lastMsgSql = "UPDATE chats SET last_message='"+ message +"', updated_at="+created_at+" WHERE chatid = " + chat_id
        con.query(lastMsgSql, function (err, lastMsgSqlResult) {
            console.log(err+lastMsgSqlResult)
            let idsArray = receiver.split(',');
            for(var i = 0; i < idsArray.length; i++) {
                let channelName = "channelList/" + idsArray[i]
                io.emit(channelName, {"chatid":chat_id, "userIds":userids,"createdBy":sender, "channelName":name, "channelType" : channelType, "last_message":message, "updated_at":created_at, "channelPic" : photo});
            }
        })
      })
    }
      
    function checkChannelAvailabelORNot(msg) {
        let chat_id = msg.chat_id
        con.connect(function(err) {
            var newChatSql = "SELECT * FROM chats WHERE chatid = " + chat_id
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                console.log(err+newChatSqlResult)
                if(newChatSqlResult.length > 0){
                    updateChannelData(msg)
                }else{
                    insertChannelData(msg)
                }
            })
        })
    }
      
    function insertChannelData(msg){
      let chat_id = msg.chat_id
      let sender = msg.sender
      let receiver = msg.receiver
      let message = msg.message.toString()
      let channelType = msg.channelType.toString()
      let created_at = getTimeStamp()
      let name = msg.name.toString()
      let photo = msg.photo.toString()
      let senderName = msg.senderName.toString()
      let userids = sender + "," + receiver
      
      let insertSqlChatList = "INSERT INTO chats (chatid, userIds, createdBy, channelName, channelType, channelPic, last_message, created_at, updated_at) values("+chat_id +",'"+userids +"','"+sender +"','"+name +"','"+channelType +"','"+photo +"','"+message +"','"+created_at +"','"+created_at+"')"
                           
        con.query(insertSqlChatList, function (err, newChatListSqlResult) {
            console.log(err+newChatListSqlResult)
            if(newChatListSqlResult){
                let idsArray = receiver.split(',');
                for(var i = 0; i < idsArray.length; i++) {
                    let channelName = "channelList/" + idsArray[i]
                    io.emit(channelName,{ "chatid" : chat_id, "userIds" :userids, "createdBy":sender, "channelName" : name, "channelType" : channelType, "last_message" : message, "created_at" : created_at, "channelPic" : photo })
                }
            }
        })
    }
      
    function updateUsersOnlineStatus(status,id){
      con.connect(function(err) {
        var updateUserStatus = "UPDATE users SET onlinestatus = "+status+" WHERE id = "+id
        con.query(updateUserStatus, function (err, newUserSqlResult) {
            if(newUserSqlResult){
                console.log("user connected"+status)
            }
        })
      })
    }
      
    socket.on('getMessageHistory', function(data,callback) {
        var lastUpdatedTime = data.updated_at;
        var id = data.id.toString();
        var newMsgSql = "select * from chat_messages where (FIND_IN_SET('"+id+"',receiver) OR sender = "+id+") AND updated_at > " + lastUpdatedTime
        console.log(newMsgSql)
        con.query(newMsgSql, function (err, newMsgSqlResult) {
            if(newMsgSqlResult.length > 0){
                callback(newMsgSqlResult)
            }else{
                callback(newMsgSqlResult)
            }
        })
    })
      
    socket.on('ChangeStatus', function(data,callback){
        let is_read = data.is_read.toString()
        let id = data.id.toString()
        let sender = data.sender.toString()
        let updated_at = getTimeStamp()
        con.connect(function(err) {
            var newChatSql = "UPDATE chat_messages SET is_read = '"+ is_read +"',updated_at = " +updated_at+ " WHERE id = '"+id+"'"
            con.query(newChatSql, function (err, newChatSqlResult) {
                if (newChatSqlResult) {
                    let channelName = "ChangeStatus/" + sender
                    io.emit(channelName, data)
                }
            });
        });
    });

    socket.on('UserList', function(callback){
        con.connect(function(err) {
            var newChatSql = "Select * from users"
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult){
                    callback(newChatSqlResult)
                }
            })
        })
    })
      
    socket.on('UserTyping', function(data, callback){
        let sender = data.sender.toString()
        let receiver = data.receiver.toString()
        let channelName = "getTyping/" + receiver
        io.emit(channelName, data);
    })
      
      
    socket.on('channelList', function(data,callback){
        let sender_Id = data.senderId.toString()
        let updated_at = data.updated_at
        con.connect(function(err) {
            var newChatSql = "Select * from chats WHERE FIND_IN_SET('"+sender_Id+"',UserIDs) AND updated_at > "+updated_at;
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult.length > 0){
                    var arr2 = []
                    var groups = newChatSqlResult.filter(function(x){return x.channelType == "2"})
                    console.log(groups)
                    var broadcast = newChatSqlResult.filter(function(x){return x.channelType == "3" && x.createdBy == sender_Id})
                    console.log(broadcast)
                    var private = newChatSqlResult.filter(function(x){return x.channelType == "1"})
                    if (private.length == 0){
                      var temp = arr2
                      console.log("call back done")
                      if (groups.length > 0){
                        temp = [...temp,...groups]
                      }
                      if (broadcast.length > 0){
                        temp = [...temp,...broadcast]
                      }
                      callback(temp)
                      updateUsersOnlineStatus(1,sender_Id)
                    }
                    for(var i = 0; i < private.length; i++){
                        let obj = private[i]
                        let useridsArray = obj.userIds.split(',')
                        let FinalArray = removeFromArray(useridsArray,sender_Id)
                        var newChatSql = "Select name, photo from users WHERE id = "+FinalArray[0]
                            console.log(newChatSql)
                            con.query(newChatSql, function (err, newUserSqlResult) {
                                obj["channelName"] = newUserSqlResult[0].name
                                obj["channelPic"] = newUserSqlResult[0].photo
                                arr2.push(obj)
                                console.log(i)
                                console.log(private.length)
                                
                                if (arr2.length == private.length){
                                    var temp = arr2
                                    console.log("call back done")
                                    if (groups.length > 0){
                                      temp = [...temp ,...groups]
                                    }
                                    if (broadcast.length > 0){
                                      temp = [...temp ,...broadcast]
                                    }
                                    callback(temp)
                                    updateUsersOnlineStatus(1,sender_Id)
                                }
                        })
                    }
                }else{
                    callback(newChatSqlResult)
                }
            });
        });
    });
              
    function removeFromArray(array, value) {
        var idx = array.indexOf(value);
        if (idx !== -1) {
            array.splice(idx, 1);
        }
        return array;
    }
      
    socket.on('Authenticate', function(data,callback){
        
        let email = data.email.toString();
        let password = data.password.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult){
                    callback(newChatSqlResult[0])
                }else{
                    callback(newChatSqlResult)
                }
            });
        });
    });
      
    //check one to one chat Exist or not
    socket.on('GetChatId', function(data,callback){
        let UserIDs = data.UserIDs.toString()
        let channelType = data.channelType.toString()
        con.connect(function(err) {
            let idsArray = UserIDs.split(',');
            var newData = "";
            for(var i = 0; i < idsArray.length; i++){
                if (idsArray.length - 1 == i) {
                    newData += "FIND_IN_SET('"+idsArray[i].trim()+"', UserIDs)"
                }else{
                    newData += "FIND_IN_SET('"+idsArray[i].trim()+"', UserIDs) AND "
                }
            }
            var newChatSql = "SELECT * FROM chats WHERE " + newData + " AND channelType = '"+channelType+"'"
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                console.log(newChatSqlResult)
                if(newChatSqlResult.length > 0) {
                    callback({"ChatId":newChatSqlResult[0].chatid})
                }else{
                    callback({"ChatId":getTimeStamp()})
                }
            })
        })
    })
      
    function getTimeStamp() {
        var milliseconds = (new Date).getTime()
        return milliseconds
    }
      
    //Create Group
    socket.on('CreateGroup', function(data,callback){
        let userids = data.userids.toString()
        let chat_id = getTimeStamp()
        let channelName = data.channelName.toString()
        let channelType = data.channelType.toString()
        let createdBy = data.createdBy
        let channelPic = data.channelPic.toString()
        let created_at = getTimeStamp()
              
        con.connect(function(err) {
            let insertSqlChatList = "INSERT INTO chats(chatid,userIds,createdBy,channelName,channelType,channelPic,last_message,created_at,updated_at) values("+chat_id+",'"+userids+"',"+createdBy+",'"+channelName+"','"+channelType+"','"+channelPic+"','','"+created_at+"','"+created_at+"')"
                    
            con.query(insertSqlChatList, function (err, newChatSqlResult) {
                console.log(err+newChatSqlResult)
                if (newChatSqlResult) {
                    let query = "Select * from chats where chatid = "+chat_id
                    con.query(query, function (err, newSqlResult) {
                        console.log(err+newSqlResult)
                        if(newSqlResult.length > 0) {
                            callback(newSqlResult)
                        }else{
                            callback(newSqlResult)
                        }
                    })
                }else{
                    callback(newChatSqlResult)
                }
            })
        })
    })
      
    socket.on('SignUp', function(data,callback){
        let email = data.email.toString();
        let password = data.password.toString();
        let name = data.name.toString();
        let photo = data.photo.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            con.query(newChatSql, function (err, newChatSqlResult) {
                
                if(newChatSqlResult.length > 0){
                    let obj = newChatSqlResult[0]
                    callback(obj)
                }else{
                    var newChatSql = "Insert into users (name,email,photo,password,onlinestatus) values('"+name+"','"+ email +"','" +photo +"','"+password+"', 1); SELECT * from users where id = LAST_INSERT_ID()"
                    con.query(newChatSql, function (err, newSqlResult) {
                        
                        if(newSqlResult){
                              let obj = newSqlResult[1][0]
                              console.log(obj)
                              callback(obj)
                        }else{
                            callback("error while insert record")
                        }
                    });
                }
            });
        });
    });
      
	socket.on('disconnect', function(){
        let sender = socket.handshake.query.user_id;
		console.log('user disconnected'+ sender);
        if(sender != "") {
            updateUsersOnlineStatus(0,sender)
        }
	});
});

http.listen(3000, function(){
	console.log('listening on *:3000');
});
