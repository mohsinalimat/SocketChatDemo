var express = require('express');
const app = express();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var mysql = require('mysql');
const multer = require('multer');
var upload = multer({ dest: '/tmp/'});
var fs = require("fs");

var con = mysql.createConnection({
	host: "localhost",
    port : "3306",
	user: "root",
	password: "",
	database: "socket",
    charset : 'utf8mb4_bin'
});

app.use(express.static('public'));

app.get('/', function(req, res){
	res.sendFile(__dirname + '/index.html');
});

// File input field name is simply 'file'
app.post('/file_upload', upload.single('file'), function(req, res) {
    var file = "/Applications/XAMPP/xamppfiles/htdocs/Images" + '/' + req.file.originalname;
    fs.rename(req.file.path, file, function(err) {
        if (err) {
            res.send(500);
        } else {
            res.json({ message: 'File uploaded successfully',filename: "http://192.168.1.85/Images/" + req.file.originalname});
        }
    });
});

io.on('connection', function(socket){
	let sender = socket.handshake.query.user_id;
	console.log('a user connected with id - '+ sender);
    
    if(sender != "") {
      updateUsersOnlineStatus(1,sender)
    }
      
	socket.on('sendMessage', function(msg,callback){
              
		let chat_id = msg.chat_id.toString()
		let sender = msg.sender.toString()
		let receiver = msg.receiver.toString()
		let message = msg.message.toString()
        let is_read = msg.is_read.toString()
        let channelType = msg.channelType.toString()
        let created_at = msg.created_at
        let id = msg.id.toString()
        let msgtype = msg.msgtype.toString()
        let mediaurl = msg.mediaurl.toString()
        let name = msg.name.toString()
        let photo = msg.photo.toString()
              
        con.connect(function(err) {
                    
            var newChatSql = "SELECT * FROM chats WHERE chatid = '" + chat_id + "'"
            
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult.length > 0){
                    var lastMsgSql = "UPDATE chats SET last_message='"+ message +"', updated_at="+created_at+" WHERE chatid = '"+chat_id+"'";
                    
                    con.query(lastMsgSql, function (err, lastMsgSqlResult) {
                        
                        let userids = sender + "," + receiver
                        let idsArray = receiver.split(',');
                        for(var i = 0; i < idsArray.length; i++) {
                              let channelName = "channelList/" + idsArray[i]
                              io.emit(channelName, {"chatid":chat_id, "userIds":userids, "channelName":name, "channelType" : channelType, "last_message":message, "updated_at":created_at, "channelPic" : photo});
                        }
                    })
                }else{
                    let userids = sender + "," + receiver
                    let insertSqlChatList = "INSERT INTO chats(chatid,userIds,channelName,channelType,channelPic,last_message,created_at,updated_at) values('"+chat_id+"','"+userids+"','"+name+"','"+channelType+"','"+photo+"','"+message+"','"+created_at+"','"+created_at+"')"
                    
                    con.query(insertSqlChatList, function (err, newChatListSqlResult) {
                        if(newChatListSqlResult){
                              
                              let idsArray = receiver.split(',');
                              for(var i = 0; i < idsArray.length; i++) {
                                    
                                    let channelName = "channelList/" + idsArray[i]
                                    io.emit(channelName,{ "chatid" : chat_id, "userIds" :userids, "channelName" : name, "channelType" : channelType, "last_message" : message, "created_at" : created_at, "channelPic" : photo })
                              }
                        }
                    })
                }
            })
            
            var newMsgSql = "INSERT INTO chat_messages(id, chat_id, message, is_read, sender,receiver,msgtype,mediaurl,created_at,updated_at) VALUES ('"+id+"','"+chat_id+"','"+ message+"','1','"+sender+"','"+receiver+"',"+msgtype+",'"+mediaurl+"',"+created_at+","+created_at+")"
            
            con.query(newMsgSql, function (err, newMsgSqlResult) {
                if(newMsgSqlResult){
                    msg.is_read = "1"
                    callback(msg)
                    let idsArray = receiver.split(',');
                    for(var i = 0; i < idsArray.length; i++){
                        let channelName = "receiveMessage/" + idsArray[i]
                        io.emit(channelName, msg)
                    }
                }
            })
        })
	})
      
    function updateUsersOnlineStatus(status,id){
      con.connect(function(err) {
        var updateUserStatus = "UPDATE users SET onlinestatus = "+status+" WHERE id = '"+id+"'";
        con.query(updateUserStatus, function (err, newUserSqlResult) {
            if(newUserSqlResult){
                console.log("user connected"+status)
            }
        });
      })
    }
      
    socket.on('getMessageHistory', function(data,callback) {
        var lastUpdatedTime = data.updated_at;
        var id = data.id.toString();
        var newMsgSql = "select * from chat_messages where (FIND_IN_SET('"+id+"',receiver) OR sender = '"+id+"') AND updated_at > " + lastUpdatedTime
        console.log(newMsgSql)
        con.query(newMsgSql, function (err, newMsgSqlResult) {
            if(newMsgSqlResult.length > 0){
                callback(newMsgSqlResult)
            }else{
                callback(newMsgSqlResult)
            }
        })
    })
      
    socket.on('ChangeStatus', function(data,callback){
        let is_read = data.is_read.toString();
        let id = data.id.toString();
        let sender = data.sender.toString();
        let updated_at = data.updated_at;
        con.connect(function(err) {
            var newChatSql = "UPDATE chat_messages SET is_read = '"+ is_read +"',updated_at = " +updated_at+ " WHERE id = '"+id+"'"
            con.query(newChatSql, function (err, newChatSqlResult) {
                if (newChatSqlResult) {
                    let channelName = "ChangeStatus/" + sender
                    io.emit(channelName, data)
                }
            });
        });
    });

      
    socket.on('UserList', function(callback){
              
        con.connect(function(err) {
            var newChatSql = "Select * from users"
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult){
                    callback(newChatSqlResult)
                }
            });
        });
    });
      
    socket.on('UserTyping', function(data, callback){
        let sender = data.sender.toString();
        let receiver = data.receiver.toString();
        let channelName = "getTyping/" + receiver
        io.emit(channelName, data);
    });
      
      
    socket.on('channelList', function(data,callback){
        let sender_Id = data.senderId.toString();
        let updated_at = data.updated_at;
        con.connect(function(err) {
            var newChatSql = "Select * from chats WHERE FIND_IN_SET('"+sender_Id+"',UserIDs) AND updated_at > "+updated_at;
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult.length > 0){
                    var arr2 = [];
                    for(var i = 0; i < newChatSqlResult.length; i++){
                      let obj = newChatSqlResult[i]
                      if (obj.channelType == "1") {
                        arr2.push(obj)
                        if (arr2.length == newChatSqlResult.length){
                            
                            callback(arr2)
                            updateUsersOnlineStatus(1,sender_Id)
                        }
                      }else{
                        let useridsArray = obj.userIds.split(',')
                        let FinalArray = removeFromArray(useridsArray,sender_Id)
                        var newChatSql = "Select name, photo from users WHERE id ='"+FinalArray[0]+"'"
                      
                        con.query(newChatSql, function (err, newUserSqlResult) {
                            obj["channelName"] = newUserSqlResult[0].name
                            obj["channelPic"] = newUserSqlResult[0].photo
                            arr2.push(obj)
                            if (arr2.length == newChatSqlResult.length){
                                callback(arr2)
                                updateUsersOnlineStatus(1,sender_Id)
                            }
                        });
                      }
                    }
                }else{
                    callback(newChatSqlResult)
                }
            });
        });
    });
              
    function removeFromArray(array, value) {
        var idx = array.indexOf(value);
        if (idx !== -1) {
            array.splice(idx, 1);
        }
        return array;
    }
      
    socket.on('Authenticate', function(data,callback){
        
        let email = data.email.toString();
        let password = data.password.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult){
                    callback(newChatSqlResult[0])
                }else{
                    callback(newChatSqlResult)
                }
            });
        });
    });
      
    //check one to one chat Exist or not
    socket.on('GetChatId', function(data,callback){
        let UserIDs = data.UserIDs.toString()
        let channelType = data.channelType.toString()
        con.connect(function(err) {
            let idsArray = UserIDs.split(',');
            var newData = "";
            for(var i = 0; i < idsArray.length; i++){
                if (idsArray.length - 1 == i) {
                    newData += "FIND_IN_SET('"+idsArray[i].trim()+"', UserIDs)"
                }else{
                    newData += "FIND_IN_SET('"+idsArray[i].trim()+"', UserIDs) AND "
                }
            }
            var newChatSql = "SELECT * FROM chats WHERE " + newData + " AND channelType = '"+channelType+"'"
            console.log(newChatSql)
            con.query(newChatSql, function (err, newChatSqlResult) {
                if(newChatSqlResult.length > 0) {
                      callback({"ChatId":newChatSqlResult[0].chatid})
                }else{
                    callback({"ChatId":makeid(8)})
                }
            })
        })
    })
      
    //Create Group
    socket.on('CreateGroup', function(data,callback){
        let userids = data.userids.toString()
        let chat_id = makeid(8)
        let channelName = data.channelName.toString()
        let channelType = data.channelType.toString()
        let channelPic = data.channelPic.toString()
        let created_at = data.created_at
              
        con.connect(function(err) {
            let insertSqlChatList = "INSERT INTO chats(chatid,userIds,channelName,channelType,channelPic,last_message,created_at,updated_at) values('"+chat_id+"','"+userids+"','"+channelName+"','"+channelType+"','"+channelPic+"','','"+created_at+"','"+created_at+"')"
                    
            con.query(insertSqlChatList, function (err, newChatSqlResult) {
                if (newChatSqlResult) {
                    let query = "Select * from chats where chatid = '"+chat_id+"'"
                    con.query(query, function (err, newSqlResult) {
                        if(newSqlResult.length > 0) {
                            callback(newSqlResult)
                        }else{
                            callback(newSqlResult)
                        }
                    })
                }else{
                    callback(newChatSqlResult)
                }
            })
        })
    })
      
    socket.on('SignUp', function(data,callback){
        let email = data.email.toString();
        let password = data.password.toString();
        let name = data.name.toString();
        let photo = data.photo.toString();
        con.connect(function(err) {
            var newChatSql = "Select * from users where email = '" + email + "' AND password = '" + password + "'"
            con.query(newChatSql, function (err, newChatSqlResult) {
                
                if(newChatSqlResult.length > 0){
                    let obj = newChatSqlResult[0]
                    callback(obj)
                }else{
                    
                    let id = makeid(5)
                    
                    var newChatSql = "Insert into users values('" +id+ "','" + name + "','" + email + "','" + photo + "','" + password + "', 1)"
                    con.query(newChatSql, function (err, newSqlResult) {
                        
                        if(newSqlResult){
                              callback({"name" : name,"email":email,"id":id})
                        }else{
                            callback("error while insert record")
                        }
                    });
                }
            });
        });
    });

    function makeid(length) {
      var result           = '';
      var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var charactersLength = characters.length;
      for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }
      return result;
    }
      
	socket.on('disconnect', function(){
        let sender = socket.handshake.query.user_id;
		console.log('user disconnected'+ sender);
        if(sender != "") {
            updateUsersOnlineStatus(0,sender)
        }
	});
});

http.listen(3000, function(){
	console.log('listening on *:3000');
});
