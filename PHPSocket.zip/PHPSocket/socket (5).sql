-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 06, 2019 at 03:58 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socket`
--

-- --------------------------------------------------------

--
-- Table structure for table `ChannelType`
--

CREATE TABLE `ChannelType` (
  `id` int(2) NOT NULL,
  `ChannelType` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `ChannelType`
--

INSERT INTO `ChannelType` (`id`, `ChannelType`) VALUES
(1, 'Private'),
(2, 'Group'),
(3, 'Broadcast');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chatid` bigint(20) NOT NULL,
  `userIds` varchar(50000) NOT NULL,
  `createdBy` bigint(20) NOT NULL,
  `channelName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `channelType` varchar(2) NOT NULL,
  `channelPic` varchar(1000) NOT NULL,
  `last_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chatid`, `userIds`, `createdBy`, `channelName`, `channelType`, `channelPic`, `last_message`, `created_at`, `updated_at`) VALUES
(1565090736, '14,12', 0, 'prashant', '0', 'http://192.168.1.85/Images/E24CC30E-9588-4290-A16D-5D87F06FF53A.jpeg', '', 1565090931317, 1565099385422),
(1565090762, '12,13,14', 0, 'Vishal Group', '1', 'http://192.168.1.85/Images/565EC999-DB02-4244-9C2B-46CF0FE3F3E0.jpeg', 'Ccc', 1565090762564, 1565099309480);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) NOT NULL,
  `chat_id` bigint(20) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `is_read` varchar(11) DEFAULT '0',
  `senderName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `sender` bigint(20) NOT NULL,
  `receiver` varchar(1000) NOT NULL,
  `msgtype` int(11) NOT NULL,
  `mediaurl` varchar(10000) NOT NULL,
  `created_at` double NOT NULL,
  `updated_at` double NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `message`, `is_read`, `senderName`, `sender`, `receiver`, `msgtype`, `mediaurl`, `created_at`, `updated_at`, `date`) VALUES
(1565090777190, 1565090762, 'Hello', '3', 'prashant', 14, '12,13', 0, '', 1565090777190, 1565098842099, '2019-08-06 13:40:42'),
(1565090919773, 1565090762, 'Heelo', '3', 'prashant', 14, '12,13', 0, '', 1565090919773, 1565098842100, '2019-08-06 13:40:42'),
(1565090931317, 1565090736, 'Hello', '3', 'prashant', 14, '12', 0, '', 1565090931317, 1565093314001, '2019-08-06 12:11:25'),
(1565093745562, 1565090762, 'Hello', '3', 'vishal', 12, '13,14', 0, '', 1565093745562, 1565098842101, '2019-08-06 13:40:42'),
(1565093748202, 1565090762, 'Hello', '3', 'vishal', 12, '13,14', 0, '', 1565093748202, 1565098842101, '2019-08-06 13:40:42'),
(1565093764354, 1565090762, 'Gdfdgd', '3', 'vishal', 12, '13,14', 0, '', 1565093764354, 1565098842102, '2019-08-06 13:40:42'),
(1565094065904, 1565090762, 'Dgdfgdfg', '3', 'vishal', 12, '13,14', 0, '', 1565094065904, 1565098842104, '2019-08-06 13:40:42'),
(1565094089475, 1565090762, 'Dgdfgdfg', '3', 'vishal', 12, '13,14', 0, '', 1565094089475, 1565098842115, '2019-08-06 13:40:42'),
(1565094115643, 1565090762, 'Dgdfgdfg', '3', 'vishal', 12, '13,14', 0, '', 1565094115643, 1565098842116, '2019-08-06 13:40:42'),
(1565094209861, 1565090762, 'Fgfghfghfh', '3', 'vishal', 12, '13,14', 0, '', 1565094209861, 1565098842117, '2019-08-06 13:40:42'),
(1565094299620, 1565090762, 'Sfsdfsdfsfsdf', '3', 'vishal', 12, '13,14', 0, '', 1565094299620, 1565098842118, '2019-08-06 13:40:42'),
(1565094354933, 1565090762, 'Sfsdfsdfds', '3', 'vishal', 12, '13,14', 0, '', 1565094354933, 1565098842118, '2019-08-06 13:40:42'),
(1565096123674, 1565090762, 'Dfdgdfgdfg', '3', 'vishal', 12, '13,14', 0, '', 1565096123674, 1565098842119, '2019-08-06 13:40:42'),
(1565096134234, 1565090762, 'Fgfhfghfhfgh', '3', 'vishal', 12, '13,14', 0, '', 1565096134234, 1565098842120, '2019-08-06 13:40:42'),
(1565096160714, 1565090762, 'Sdfsdfsdfsdf', '3', 'vishal', 12, '13,14', 0, '', 1565096160714, 1565098842120, '2019-08-06 13:40:42'),
(1565097942372, 1565090762, '', '3', 'Ravi', 13, '12,14', 1, 'http://192.168.1.85/Images/2F225AD1-2C13-4B16-BE46-892151000F1D.jpeg', 1565097942372, 1565098046628, '2019-08-06 13:27:26'),
(1565098236082, 1565090762, 'Dsaadad', '3', 'Ravi', 13, '12,14', 0, '', 1565098236082, 1565098442458, '2019-08-06 13:34:02'),
(1565098243150, 1565090762, 'Dadasdasadadadasdasdasdasdasdasdasdasdasdasdadasdasdasdasdasdasdasdasdasdasdasas', '3', 'Ravi', 13, '12,14', 0, '', 1565098243150, 1565098442458, '2019-08-06 13:34:02'),
(1565098459750, 1565090762, 'Hjhjhjhjhj v bbvjghjbjgh nbjbjbjb', '3', 'Ravi', 13, '12,14', 0, '', 1565098459750, 1565098468461, '2019-08-06 13:34:28'),
(1565098660991, 1565090762, 'Abc', '3', 'Ravi', 13, '12,14', 0, '', 1565098660991, 1565098843051, '2019-08-06 13:40:43'),
(1565099254110, 1565090762, 'What a', '3', 'Ravi', 13, '12,14', 0, '', 1565099254110, 1565099835128, '2019-08-06 13:57:15'),
(1565099270213, 1565090762, 'S dsdsds', '3', 'Ravi', 13, '12,14', 0, '', 1565099270213, 1565099835128, '2019-08-06 13:57:15'),
(1565099273195, 1565090762, 'Adsaxccc', '3', 'Ravi', 13, '12,14', 0, '', 1565099273195, 1565099835129, '2019-08-06 13:57:15'),
(1565099274961, 1565090762, 'Vvv', '3', 'Ravi', 13, '12,14', 0, '', 1565099274961, 1565099835129, '2019-08-06 13:57:15'),
(1565099276311, 1565090762, 'Fff', '3', 'Ravi', 13, '12,14', 0, '', 1565099276311, 1565099835129, '2019-08-06 13:57:15'),
(1565099278107, 1565090762, 'Gggr', '3', 'Ravi', 13, '12,14', 0, '', 1565099278107, 1565099835135, '2019-08-06 13:57:15'),
(1565099297635, 1565090762, 'Hiiii', '3', 'prashant', 14, '12,13', 0, '', 1565099297635, 1565099835135, '2019-08-06 13:57:15'),
(1565099301480, 1565090762, 'Sdsd', '3', 'prashant', 14, '12,13', 0, '', 1565099301480, 1565099835136, '2019-08-06 13:57:15'),
(1565099304101, 1565090762, 'Asasasasa', '3', 'prashant', 14, '12,13', 0, '', 1565099304101, 1565099835136, '2019-08-06 13:57:15'),
(1565099306677, 1565090762, 'Wewewewewewewewe', '3', 'prashant', 14, '12,13', 0, '', 1565099306677, 1565099835136, '2019-08-06 13:57:15'),
(1565099308276, 1565090762, 'Fdfdfd', '3', 'prashant', 14, '12,13', 0, '', 1565099308276, 1565099835137, '2019-08-06 13:57:15'),
(1565099309480, 1565090762, 'Ccc', '3', 'prashant', 14, '12,13', 0, '', 1565099309480, 1565099835137, '2019-08-06 13:57:15'),
(1565099322946, 1565090736, 'Hey', '3', 'prashant', 14, '12', 0, '', 1565099322946, 1565099838231, '2019-08-06 13:57:18'),
(1565099329929, 1565090736, 'Yyutyutyu', '3', 'vishal', 12, '14', 0, '', 1565099329929, 1565099330226, '2019-08-06 13:48:50'),
(1565099333495, 1565090736, 'Ytutyuytu', '3', 'vishal', 12, '14', 0, '', 1565099333494, 1565099333606, '2019-08-06 13:48:53'),
(1565099385422, 1565090736, '', '3', 'prashant', 14, '12', 1, 'http://192.168.1.85/Images/A4CB1BBE-6404-4155-A086-87FE17DF9434.jpeg', 1565099385422, 1565099838232, '2019-08-06 13:57:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `onlinestatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `photo`, `password`, `onlinestatus`) VALUES
(12, 'vishal', 'vishal@gmail.com', 'http://192.168.1.85/Images/EE1C5EC2-99E2-4529-95AB-1E35ADAEC0A7.jpeg', '123', 1),
(13, 'Ravi', 'ravi@gmail.com', 'http://192.168.1.85/Images/D952E2D0-796C-4FDE-A357-B9EF9C7A305C.jpeg', '123', 1),
(14, 'prashant', 'prashant@gmail.com', 'http://192.168.1.85/Images/E24CC30E-9588-4290-A16D-5D87F06FF53A.jpeg', '123', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ChannelType`
--
ALTER TABLE `ChannelType`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ChannelType`
--
ALTER TABLE `ChannelType`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
